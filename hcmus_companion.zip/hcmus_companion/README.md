# HCMUS Companion – Smart Virtual Assistant

**CSC10014 – Computational Thinking 2026** | FIT@HCMUS

Web app hoàn chỉnh: **FastAPI backend + giao diện HTML/CSS/JS**.

## Chạy trên localhost

```bash
cd hcmus_companion
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Mở trình duyệt: **http://localhost:8000**

## Tính năng

| Tính năng | Mô tả |
|-----------|--------|
| Chat assistant | Pipeline UNDERSTAND → ROUTE → RETRIEVE/COMPUTE → RESPOND |
| Upload TKB | CSV / Excel / JSON → cá nhân hóa lịch, kế hoạch tuần |
| Crawl thông báo | Lấy tin từ fit.hcmus.edu.vn (có cache + fallback) |
| Deterministic | Kiểm tra xung đột lịch, lập kế hoạch tuần |
| REST API | `/api/chat`, `/api/upload-tkb`, `/api/refresh-news`, … |

## API chính

| Method | Endpoint | Mô tả |
|--------|----------|--------|
| GET | `/` | Giao diện web |
| GET | `/api/health` | Trạng thái hệ thống |
| POST | `/api/chat` | `{ "message": "..." }` → câu trả lời |
| POST | `/api/upload-tkb` | Upload file TKB (multipart) |
| DELETE | `/api/tkb` | Xóa TKB cá nhân |
| POST | `/api/refresh-news` | Crawl thông báo FIT |
| GET | `/api/sample-csv` | Tải file CSV mẫu |

## Cấu trúc

```
hcmus_companion/
├── main.py              # FastAPI entrypoint
├── templates/index.html # Giao diện web
├── static/
│   ├── style.css
│   └── app.js
├── src/                 # Logic (router, handlers, crawler, parser…)
├── data/                # JSON schedules, regulations, announcements
├── cli.py               # CLI (tùy chọn)
└── requirements.txt
```

## Legacy Streamlit (tùy chọn)

```bash
streamlit run app.py
```

## Kiến trúc đáp ứng R1–R8

- **R1** Problem boundary rõ (scope + non-goals trong code/README)
- **R2** Deterministic: conflict check, week planner
- **R3** Retrieval: JSON local + crawl FIT website
- **R4** AI-ready: rule-based intent (có thể thay LLM)
- **R5** Routing + clarification + fallback
- **R6** End-to-end web UI + REST API
- **R7** Validation, out-of-scope reject, error handling
- **R8** Có thể gắn test set qua `/api/chat`
