#!/usr/bin/env python3
"""CLI version of HCMUS Companion – useful for testing & evaluation."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from src.router import Router


def main():
    router = Router()
    print("=" * 60)
    print("  🎓 HCMUS Companion – CLI Mode")
    print("  Gõ 'quit' hoặc 'exit' để thoát")
    print("=" * 60)
    print()

    while True:
        try:
            user_input = input("Bạn: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nTạm biệt!")
            break

        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "q"):
            print("Tạm biệt!")
            break

        result = router.handle(user_input)
        print(f"\nBot [{result['intent']} | conf={result['confidence']:.2f}]:")
        print(result["response"])
        print("-" * 40)


if __name__ == "__main__":
    main()
