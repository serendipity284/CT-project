"""
Crawler lấy thông báo từ website FIT@HCMUS (R3 - external data source).
Fallback về dữ liệu local nếu crawl thất bại.
"""
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Optional

import requests
from bs4 import BeautifulSoup

DATA_DIR = Path(__file__).parent.parent / "data"
CACHE_FILE = DATA_DIR / "announcements_live.json"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; HCMUSCompanion/1.0; Academic Project)"
}

# Các mục thông báo quan trọng cho sinh viên CQ
TARGET_SECTIONS = [
    "Thông báo Chương trình chuẩn",
    "Thông báo chung",
    "Thông tin học bổng",
]


def crawl_fit_announcements(limit: int = 15) -> list[dict]:
    """Crawl trang tin tức FIT, trả về list thông báo."""
    url = "https://www.fit.hcmus.edu.vn/tin-tuc"
    try:
        resp = requests.get(url, headers=HEADERS, timeout=12)
        resp.raise_for_status()
        resp.encoding = resp.apparent_encoding or "utf-8"
    except Exception as e:
        raise RuntimeError(f"Không kết nối được tới FIT website: {e}") from e

    soup = BeautifulSoup(resp.text, "lxml")
    results = []
    seen_titles = set()

    # Tìm các heading section
    for header in soup.find_all(["h6", "h5", "h4", "strong", "b"]):
        section_name = header.get_text(strip=True)
        if not any(s.lower() in section_name.lower() for s in TARGET_SECTIONS):
            # Vẫn lấy nếu chứa từ khóa liên quan
            if not any(k in section_name.lower() for k in ["thông báo", "chương trình chuẩn", "học bổng"]):
                continue

        # Lấy các link ngay sau header
        parent = header.find_parent(["div", "section", "li", "ul"]) or header.parent
        links = parent.find_all("a", href=True) if parent else []
        # Nếu ít link, thử sibling tiếp theo
        if len(links) < 2:
            nxt = header.find_next_sibling()
            if nxt:
                links = nxt.find_all("a", href=True) if hasattr(nxt, "find_all") else []

        for a in links[:8]:
            title = a.get_text(strip=True)
            href = a["href"]
            if not title or len(title) < 10 or title in seen_titles:
                continue
            if href.startswith("/"):
                href = "https://www.fit.hcmus.edu.vn" + href
            seen_titles.add(title)

            # Đoán priority
            priority = "medium"
            lower = title.lower()
            if any(k in lower for k in ["tkb", "thời khóa biểu", "đăng ký", "deadline", "hạn", "thi"]):
                priority = "high"
            elif any(k in lower for k in ["học bổng", "tuyển dụng"]):
                priority = "low"

            results.append({
                "id": f"LIVE_{len(results)+1:03d}",
                "date": datetime.now().strftime("%Y-%m-%d"),
                "title": title,
                "content": f"Xem chi tiết tại: {href}",
                "url": href,
                "priority": priority,
                "source": "fit.hcmus.edu.vn",
                "section": section_name,
                "keywords": _extract_keywords(title),
            })
            if len(results) >= limit:
                break
        if len(results) >= limit:
            break

    # Fallback: lấy mọi link tin tức nếu chưa đủ
    if len(results) < 5:
        for a in soup.select("a[href*='/tin-tuc/d/']")[:limit]:
            title = a.get_text(strip=True)
            href = a["href"]
            if not title or title in seen_titles:
                continue
            if href.startswith("/"):
                href = "https://www.fit.hcmus.edu.vn" + href
            seen_titles.add(title)
            results.append({
                "id": f"LIVE_{len(results)+1:03d}",
                "date": datetime.now().strftime("%Y-%m-%d"),
                "title": title,
                "content": f"Xem chi tiết tại: {href}",
                "url": href,
                "priority": "medium",
                "source": "fit.hcmus.edu.vn",
                "section": "Chung",
                "keywords": _extract_keywords(title),
            })

    return results[:limit]


def _extract_keywords(title: str) -> list[str]:
    keywords = []
    lower = title.lower()
    mapping = {
        "đăng ký": "đăng ký môn",
        "tkb": "thời khóa biểu",
        "thời khóa biểu": "thời khóa biểu",
        "học bổng": "học bổng",
        "thi": "lịch thi",
        "deadline": "deadline",
        "hạn": "hạn chót",
        "nghỉ học": "nghỉ học",
        "phòng học": "phòng học",
    }
    for k, v in mapping.items():
        if k in lower:
            keywords.append(v)
    return keywords or ["thông báo"]


def save_live_announcements(items: list[dict]) -> Path:
    payload = {
        "crawled_at": datetime.now().isoformat(timespec="seconds"),
        "source": "https://www.fit.hcmus.edu.vn/tin-tuc",
        "count": len(items),
        "announcements": items,
    }
    CACHE_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return CACHE_FILE


def load_live_announcements() -> Optional[dict]:
    if not CACHE_FILE.exists():
        return None
    try:
        return json.loads(CACHE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None


def refresh_announcements() -> tuple[bool, str, list[dict]]:
    """
    Thử crawl → lưu cache.
    Trả về (success, message, list_announcements).
    """
    try:
        items = crawl_fit_announcements(limit=12)
        if not items:
            return False, "Crawl thành công nhưng không tìm thấy thông báo.", []
        save_live_announcements(items)
        return True, f"Đã lấy {len(items)} thông báo từ fit.hcmus.edu.vn", items
    except Exception as e:
        return False, f"Crawl thất bại: {e}. Dùng dữ liệu local.", []
