"""Orchestration / Routing layer (R5)."""
from src.data_loader import DataStore
from src.intent import classify_intent, ParsedRequest
from src.handlers import schedule, info


class Router:
    def __init__(self):
        self.store = DataStore()

    def handle(self, user_input: str) -> dict:
        """
        Full pipeline:
        REQUEST → UNDERSTAND → ROUTE → RETRIEVE/COMPUTE → VERIFY → RESPOND
        """
        # 1. UNDERSTAND
        parsed: ParsedRequest = classify_intent(user_input)

        # 2. Early exit for clarification — nhưng bỏ qua nếu đã có TKB cá nhân
        if parsed.needs_clarification and parsed.clarification_question:
            # Nếu hỏi lịch/kế hoạch mà đã có TKB cá nhân → không cần hỏi mã lớp
            if parsed.intent in ("schedule_query", "plan_week") and self.store.get_personal_schedule():
                pass  # tiếp tục xử lý với TKB cá nhân
            else:
                return {
                    "intent": parsed.intent,
                    "response": parsed.clarification_question,
                    "type": "clarification",
                    "confidence": parsed.confidence,
                }

        # 3. ROUTE + EXECUTE
        intent = parsed.intent
        entities = parsed.entities

        if intent == "out_of_scope":
            response = info.handle_out_of_scope()
            resp_type = "reject"
        elif intent == "schedule_query":
            class_id = entities.get("class_id")
            day = entities.get("day")
            response = schedule.handle_schedule_query(self.store, class_id, day)
            resp_type = "schedule"
        elif intent == "room_query":
            class_id = entities.get("class_id")
            day = entities.get("day")
            response = schedule.handle_room_query(self.store, class_id, day)
            resp_type = "room"
        elif intent == "conflict_check":
            class_id = entities.get("class_id")
            # For demo: if no detailed period, give guidance
            if not class_id:
                response = "Để kiểm tra xung đột, hãy cho mình biết mã lớp và thời gian muốn thêm (ví dụ: \"kiểm tra xung đột lớp 21CTT1 thứ 4 tiết 4-6\")."
            else:
                # Try to extract period from raw text (simple)
                import re
                period_match = re.search(r"tiết\s*(\d-\d)", user_input.lower())
                day = entities.get("day")
                if period_match and day:
                    response = schedule.check_conflict(self.store, class_id, day, period_match.group(1))
                else:
                    response = (
                        f"Lớp {class_id} hiện có lịch:\n"
                        + schedule.format_schedule(self.store.get_class_schedule(class_id)["schedule"])
                        + "\n\nHãy cho thêm ngày và tiết muốn kiểm tra (vd: thứ 4 tiết 4-6)."
                    )
            resp_type = "conflict"
        elif intent == "regulation_query":
            response = info.handle_regulation(self.store, user_input)
            resp_type = "regulation"
        elif intent == "announcement_query":
            response = info.handle_announcement(self.store, user_input)
            resp_type = "announcement"
        elif intent == "deadline_query":
            response = info.handle_deadline(self.store)
            resp_type = "deadline"
        elif intent == "plan_week":
            class_id = entities.get("class_id")
            # Nếu có TKB cá nhân thì dùng luôn, không bắt buộc mã lớp
            if not class_id and self.store.get_personal_schedule():
                class_id = "PERSONAL"
            if not class_id:
                response = (
                    "Bạn muốn lập kế hoạch cho lớp nào? (ví dụ: 21CTT1)\n"
                    "Hoặc upload TKB cá nhân ở sidebar rồi hỏi lại."
                )
                resp_type = "clarification"
            else:
                response = schedule.simple_week_plan(self.store, class_id)
                resp_type = "plan"
        elif intent == "unknown":
            response = info.handle_unknown()
            resp_type = "unknown"
        else:
            response = info.handle_unknown()
            resp_type = "unknown"

        # 4. VERIFY (simple safeguard)
        if not response or len(response.strip()) < 5:
            response = "Xin lỗi, mình gặp lỗi khi xử lý. Bạn thử hỏi lại theo cách khác nhé."
            resp_type = "error"

        return {
            "intent": intent,
            "entities": entities,
            "response": response,
            "type": resp_type,
            "confidence": parsed.confidence,
        }
