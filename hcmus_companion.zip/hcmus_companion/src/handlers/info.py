"""Retrieval + generation handlers for regulations, announcements, deadlines."""
from src.data_loader import DataStore


def handle_regulation(store: DataStore, query: str) -> str:
    results = store.search_regulations(query)
    if not results:
        return (
            "Mình chưa tìm thấy quy định phù hợp với câu hỏi của bạn.\n"
            "Bạn có thể hỏi về: số tín chỉ, học cải thiện, bảo lưu, điểm danh, môn tiên quyết, thời gian đăng ký môn."
        )

    lines = ["📜 **Quy định liên quan:**\n"]
    for reg in results:
        lines.append(f"**{reg['title']}** (mã: {reg['id']})")
        lines.append(reg["content"])
        lines.append("")
    lines.append("_Nguồn: Dữ liệu quy định nội bộ (mock) – vui lòng đối chiếu với quy chế chính thức của trường._")
    return "\n".join(lines)


def handle_announcement(store: DataStore, query: str = "") -> str:
    if query.strip():
        results = store.search_announcements(query)
        # Fallback to recent if keyword search yields nothing
        if not results:
            results = store.get_recent_announcements(4)
    else:
        results = store.get_recent_announcements(4)

    if not results:
        return "Hiện không có thông báo nào phù hợp."

    lines = ["📢 **Thông báo:**\n"]
    for ann in results:
        priority_icon = {"high": "🔴", "medium": "🟡", "low": "🟢"}.get(ann.get("priority", "low"), "⚪")
        source = ann.get("source", "local")
        date = ann.get("date", "")
        lines.append(f"{priority_icon} **{ann['title']}** ({date})")
        lines.append(ann.get("content", ""))
        if ann.get("url"):
            lines.append(f"  🔗 {ann['url']}")
        if source and source != "local":
            lines.append(f"  _Nguồn: {source}_")
        lines.append("")
    return "\n".join(lines)


def handle_deadline(store: DataStore) -> str:
    upcoming = store.get_upcoming_deadlines(6)
    if not upcoming:
        return "Hiện không có deadline nào sắp tới trong dữ liệu."

    lines = ["⏰ **Các deadline sắp tới:**\n"]
    for dl in upcoming:
        lines.append(f"  • **{dl['date']}** – {dl['title']}")
        lines.append(f"    _{dl['description']}_")
    lines.append("\n_Hãy sắp xếp thời gian sớm để tránh bỏ sót!_")
    return "\n".join(lines)


def handle_out_of_scope() -> str:
    return (
        "🚫 **Ngoài phạm vi hỗ trợ**\n\n"
        "Mình chỉ hỗ trợ các vấn đề liên quan đến **đời sống học tập tại FIT@HCMUS**:\n"
        "• Lịch học & phòng học\n"
        "• Quy định học vụ cơ bản\n"
        "• Thông báo & deadline\n"
        "• Lập kế hoạch tuần đơn giản\n\n"
        "Mình **không** hỗ trợ: đăng ký môn thật, thanh toán học phí, tư vấn tâm lý, "
        "hoặc các chủ đề ngoài học tập. Bạn vui lòng liên hệ phòng ban chức năng nếu cần."
    )


def handle_unknown() -> str:
    return (
        "🤔 Mình chưa hiểu rõ yêu cầu của bạn.\n\n"
        "**Bạn có thể hỏi ví dụ:**\n"
        "• \"Lịch học lớp 21CTT1\"\n"
        "• \"Phòng học môn Cấu trúc dữ liệu lớp 21CTT1\"\n"
        "• \"Quy định về học cải thiện điểm\"\n"
        "• \"Thông báo mới nhất\"\n"
        "• \"Deadline sắp tới\"\n"
        "• \"Lập kế hoạch tuần cho lớp 22CTT3\"\n"
        "• \"Kiểm tra xung đột lịch lớp 21CTT1 thứ 4 tiết 4-6\""
    )
