"""Deterministic schedule handlers (R2 - Deterministic capability)."""
from typing import Optional
from src.data_loader import DataStore


def format_schedule(schedule_list: list[dict], day_filter: Optional[str] = None) -> str:
    if day_filter:
        schedule_list = [s for s in schedule_list if s["day"] == day_filter]
    if not schedule_list:
        return "Không có buổi học nào phù hợp."

    lines = []
    current_day = None
    for s in schedule_list:
        if s["day"] != current_day:
            current_day = s["day"]
            lines.append(f"\n**{current_day}**")
        lines.append(
            f"  • Tiết {s['period']} ({s['time']}): **{s['course']}** – Phòng {s['room']} – GV: {s['lecturer']}"
        )
    return "\n".join(lines).strip()


def handle_schedule_query(store: DataStore, class_id: str | None, day: Optional[str] = None) -> str:
    # Ưu tiên TKB cá nhân nếu không chỉ định lớp hoặc chỉ định PERSONAL
    if not class_id or str(class_id).upper() in ("PERSONAL", "MINE", "ME", "TÔI", "TOI"):
        personal = store.get_personal_schedule()
        if personal:
            header = f"📅 **Lịch học cá nhân** – {personal.get('name', 'TKB của bạn')}"
            body = format_schedule(personal["schedule"], day)
            src = personal.get("source", "")
            footer = f"\n\n_Nguồn: {src}_" if src else ""
            return f"{header}\n\n{body}{footer}"
        if not class_id:
            available = ", ".join(store.get_all_class_ids())
            return (
                "Bạn chưa upload TKB cá nhân và cũng chưa cho mã lớp.\n"
                "→ Upload file TKB ở sidebar, hoặc hỏi dạng: **Lịch học lớp 21CTT1**\n"
                f"Các lớp mẫu hiện có: {available}"
            )

    class_data = store.get_class_schedule(class_id)
    if not class_data:
        available = ", ".join(store.get_all_class_ids())
        return f"Không tìm thấy lớp **{class_id}**. Các lớp hiện có: {available}"

    header = f"📅 **Lịch học lớp {class_id}** – {class_data['name']}"
    body = format_schedule(class_data["schedule"], day)
    return f"{header}\n\n{body}"


def handle_room_query(store: DataStore, class_id: Optional[str], day: Optional[str] = None) -> str:
    if not class_id:
        return "Bạn cần cung cấp mã lớp để mình tìm phòng học (ví dụ: 21CTT1)."

    class_data = store.get_class_schedule(class_id)
    if not class_data:
        return f"Không tìm thấy lớp **{class_id}**."

    schedule = class_data["schedule"]
    if day:
        schedule = [s for s in schedule if s["day"] == day]

    if not schedule:
        return f"Không có buổi học nào vào {day or 'tuần này'}."

    lines = [f"📍 **Phòng học lớp {class_id}**" + (f" – {day}" if day else "")]
    for s in schedule:
        room_info = store.get_room_info(s["room"])
        extra = ""
        if room_info:
            extra = f" (tòa {room_info['building']}, sức chứa {room_info['capacity']})"
        lines.append(f"  • {s['day']} tiết {s['period']}: **{s['room']}**{extra} – {s['course']}")
    return "\n".join(lines)


def check_conflict(store: DataStore, class_id: str, new_day: str, new_period: str) -> str:
    """Deterministic conflict detection algorithm."""
    class_data = store.get_class_schedule(class_id)
    if not class_data:
        return f"Không tìm thấy lớp **{class_id}**."

    # Simple period overlap check (periods are like "1-3", "4-6", "7-9")
    def period_to_range(p: str) -> tuple[int, int]:
        parts = p.split("-")
        return int(parts[0]), int(parts[1])

    new_start, new_end = period_to_range(new_period)
    conflicts = []
    for s in class_data["schedule"]:
        if s["day"] != new_day:
            continue
        start, end = period_to_range(s["period"])
        if not (new_end < start or new_start > end):
            conflicts.append(s)

    if not conflicts:
        return f"✅ **Không xung đột**. Bạn có thể học thêm vào {new_day} tiết {new_period}."

    lines = [f"⚠️ **Phát hiện xung đột lịch** với lớp {class_id}:"]
    for c in conflicts:
        lines.append(f"  • {c['day']} tiết {c['period']} ({c['time']}): {c['course']} – Phòng {c['room']}")
    return "\n".join(lines)


def simple_week_plan(store: DataStore, class_id: str | None, free_slots: list[str] | None = None) -> str:
    """Deterministic simple weekly planner (R2)."""
    if not class_id or class_id.upper() in ("PERSONAL", "MINE", "ME", "TÔI", "TOI"):
        class_data = store.get_personal_schedule()
        label = "cá nhân"
    else:
        class_data = store.get_class_schedule(class_id)
        label = class_id

    if not class_data:
        if store.get_personal_schedule():
            return "Không tìm thấy lớp. Bạn có thể dùng TKB cá nhân: hỏi **lập kế hoạch tuần** (không cần mã lớp)."
        return f"Không tìm thấy lớp **{class_id}**. Hãy upload TKB hoặc cho mã lớp."

    lines = [
        f"📋 **Gợi ý kế hoạch tuần ({label})**",
        "",
        "**Lịch học cố định:**",
    ]
    for s in class_data["schedule"]:
        lines.append(f"  • {s['day']} {s['time']}: {s['course']} (bắt buộc)")

    lines.append("")
    lines.append("**Gợi ý thời gian tự học / ôn tập:**")
    # Simple heuristic: suggest free mornings/afternoons
    busy_days = {s["day"] for s in class_data["schedule"]}
    all_days = ["Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6"]
    suggestions = []
    for d in all_days:
        if d not in busy_days:
            suggestions.append(f"  • {d} sáng (07:30-11:00): Tự học / làm bài tập")
        else:
            # Check if afternoon free
            afternoon_busy = any(s["day"] == d and s["period"].startswith("7") for s in class_data["schedule"])
            if not afternoon_busy:
                suggestions.append(f"  • {d} chiều (13:00-17:00): Ôn tập / dự án nhóm")

    if free_slots:
        lines.append("  (Dựa thêm trên thời gian rảnh bạn cung cấp)")
    lines.extend(suggestions or ["  • Hiện tại lịch khá dày, hãy ưu tiên ôn tập vào cuối tuần."])

    lines.append("")
    lines.append("_Lưu ý: Đây chỉ là gợi ý deterministic dựa trên lịch học. Bạn nên điều chỉnh theo năng suất cá nhân._")
    return "\n".join(lines)
