"""
User authentication + profile (SQLite).
MSSV bắt buộc, chọn khoa/ngành khi đăng ký.
"""
from __future__ import annotations

import hashlib
import re
import secrets
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

DATA_DIR = Path(__file__).parent.parent / "data"
DB_PATH = DATA_DIR / "users.db"

# Khoa / ngành hỗ trợ (có thể mở rộng)
FACULTIES = {
    "fit": {
        "name": "Công nghệ Thông tin",
        "majors": {
            "cntt": "Công nghệ thông tin",
            "khmt": "Khoa học máy tính",
            "ktpm": "Kỹ thuật phần mềm",
            "mmt": "Mạng máy tính & viễn thông",
            "ttnt": "Trí tuệ nhân tạo",
            "other": "Khác (CNTT)",
        },
    },
    "math": {
        "name": "Toán - Tin học",
        "majors": {
            "toan": "Toán học",
            "toantin": "Toán tin",
            "other": "Khác (Toán)",
        },
    },
    "phys": {
        "name": "Vật lý - Vật lý kỹ thuật",
        "majors": {
            "vatly": "Vật lý",
            "other": "Khác (Vật lý)",
        },
    },
    "chem": {
        "name": "Hóa học",
        "majors": {
            "hoa": "Hóa học",
            "other": "Khác (Hóa)",
        },
    },
    "bio": {
        "name": "Sinh học - Công nghệ Sinh học",
        "majors": {
            "sinh": "Sinh học",
            "cntsinh": "Công nghệ sinh học",
            "other": "Khác (Sinh)",
        },
    },
    "other": {
        "name": "Khoa khác / Chưa xác định",
        "majors": {
            "other": "Khác",
        },
    },
}


def _hash_password(password: str, salt: Optional[str] = None) -> tuple[str, str]:
    if salt is None:
        salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt.encode("utf-8"), 100_000
    ).hex()
    return digest, salt


def _verify_password(password: str, password_hash: str, salt: str) -> bool:
    digest, _ = _hash_password(password, salt)
    return secrets.compare_digest(digest, password_hash)


def _connect() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    conn = _connect()
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mssv TEXT NOT NULL UNIQUE,
            display_name TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            salt TEXT NOT NULL,
            faculty TEXT NOT NULL,
            major TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS sessions (
            token TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
        """
    )
    conn.commit()
    conn.close()


def validate_mssv(mssv: str) -> str:
    m = mssv.strip().upper()
    # Cho phép dạng 8-10 ký tự chữ/số (linh hoạt đa khoa)
    if not re.fullmatch(r"[A-Z0-9]{6,12}", m):
        raise ValueError("MSSV không hợp lệ (6–12 ký tự chữ/số).")
    return m


def validate_faculty_major(faculty: str, major: str) -> tuple[str, str]:
    if faculty not in FACULTIES:
        raise ValueError(f"Khoa không hợp lệ. Chọn một trong: {', '.join(FACULTIES.keys())}")
    majors = FACULTIES[faculty]["majors"]
    if major not in majors:
        raise ValueError(f"Ngành không hợp lệ cho khoa này. Chọn: {', '.join(majors.keys())}")
    return faculty, major


def register_user(
    mssv: str,
    password: str,
    display_name: str,
    faculty: str,
    major: str,
) -> dict[str, Any]:
    mssv = validate_mssv(mssv)
    faculty, major = validate_faculty_major(faculty, major)
    name = display_name.strip()
    if len(name) < 2:
        raise ValueError("Tên hiển thị quá ngắn.")
    if len(password) < 6:
        raise ValueError("Mật khẩu tối thiểu 6 ký tự.")

    pw_hash, salt = _hash_password(password)
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")

    conn = _connect()
    try:
        cur = conn.execute(
            """
            INSERT INTO users (mssv, display_name, password_hash, salt, faculty, major, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (mssv, name, pw_hash, salt, faculty, major, now),
        )
        conn.commit()
        user_id = cur.lastrowid
    except sqlite3.IntegrityError as e:
        conn.close()
        raise ValueError("MSSV đã được đăng ký.") from e
    conn.close()
    return get_user_by_id(user_id)  # type: ignore


def authenticate(mssv: str, password: str) -> dict[str, Any]:
    mssv = validate_mssv(mssv)
    conn = _connect()
    row = conn.execute("SELECT * FROM users WHERE mssv = ?", (mssv,)).fetchone()
    conn.close()
    if not row:
        raise ValueError("MSSV hoặc mật khẩu không đúng.")
    if not _verify_password(password, row["password_hash"], row["salt"]):
        raise ValueError("MSSV hoặc mật khẩu không đúng.")
    return _row_to_user(row)


def create_session(user_id: int) -> str:
    token = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    conn = _connect()
    conn.execute(
        "INSERT INTO sessions (token, user_id, created_at) VALUES (?, ?, ?)",
        (token, user_id, now),
    )
    conn.commit()
    conn.close()
    return token


def delete_session(token: str) -> None:
    conn = _connect()
    conn.execute("DELETE FROM sessions WHERE token = ?", (token,))
    conn.commit()
    conn.close()


def get_user_by_token(token: Optional[str]) -> Optional[dict[str, Any]]:
    if not token:
        return None
    conn = _connect()
    row = conn.execute(
        """
        SELECT u.* FROM sessions s
        JOIN users u ON u.id = s.user_id
        WHERE s.token = ?
        """,
        (token,),
    ).fetchone()
    conn.close()
    if not row:
        return None
    return _row_to_user(row)


def get_user_by_id(user_id: int) -> Optional[dict[str, Any]]:
    conn = _connect()
    row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    if not row:
        return None
    return _row_to_user(row)


def _row_to_user(row: sqlite3.Row) -> dict[str, Any]:
    faculty = row["faculty"]
    major = row["major"]
    fac_meta = FACULTIES.get(faculty, FACULTIES["other"])
    return {
        "id": row["id"],
        "mssv": row["mssv"],
        "display_name": row["display_name"],
        "faculty": faculty,
        "faculty_name": fac_meta["name"],
        "major": major,
        "major_name": fac_meta["majors"].get(major, major),
        "created_at": row["created_at"],
    }


def list_faculties() -> dict:
    return {
        k: {
            "name": v["name"],
            "majors": v["majors"],
        }
        for k, v in FACULTIES.items()
    }


# Init on import
init_db()
