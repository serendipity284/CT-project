"""Input Understanding: Intent classification + entity extraction (R5 support)."""
import re
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ParsedRequest:
    raw: str
    intent: str
    entities: dict = field(default_factory=dict)
    confidence: float = 0.0
    needs_clarification: bool = False
    clarification_question: Optional[str] = None


# Simple rule-based intent patterns (deterministic, transparent)
INTENT_PATTERNS = {
    "schedule_query": [
        r"lịch\s*học",
        r"thời\s*khóa\s*biểu",
        r"tkb",
        r"buổi\s*học",
        r"hôm\s*nay\s*học",
        r"tuần\s*này\s*học",
        r"lịch\s*của",
    ],
    "room_query": [
        r"phòng\s*học",
        r"học\s*ở\s*phòng",
        r"phòng\s*nào",
        r"địa\s*điểm",
    ],
    "conflict_check": [
        r"xung\s*đột",
        r"trùng\s*lịch",
        r"bị\s*trùng",
        r"check\s*lịch",
        r"kiểm\s*tra\s*lịch",
    ],
    "regulation_query": [
        r"quy\s*định",
        r"quy\s*chế",
        r"tín\s*chỉ",
        r"cải\s*thiện",
        r"bảo\s*lưu",
        r"điểm\s*danh",
        r"vắng\s*học",
        r"tiên\s*quyết",
        r"đăng\s*ký\s*môn",
    ],
    "announcement_query": [
        r"thông\s*báo",
        r"thông\s*tin\s*mới",
        r"tin\s*tức",
        r"announcement",
    ],
    "deadline_query": [
        r"deadline",
        r"hạn\s*chót",
        r"hạn\s*nộp",
        r"sắp\s*tới",
        r"deadline\s*nào",
        r"hạn\s*đăng\s*ký",
    ],
    "plan_week": [
        r"kế\s*hoạch",
        r"lập\s*lịch",
        r"plan",
        r"sắp\s*xếp\s*thời\s*gian",
        r"thời\s*gian\s*rảnh",
    ],
    "out_of_scope": [
        r"đóng\s*học\s*phí",
        r"học\s*phí\s*bao\s*nhiêu",
        r"đóng\s*tiền",
        r"chuyển\s*khoản",
        r"thanh\s*toán",
        r"tư\s*vấn\s*tâm\s*lý",
        r"trầm\s*cảm",
        r"tình\s*yêu",
        r"chính\s*trị",
        r"bóng\s*đá",
    ],
}


def extract_class_id(text: str) -> Optional[str]:
    """Extract class code like 21CTT1, 22CTT3..."""
    match = re.search(r"\b(\d{2}CTT\d)\b", text.upper())
    if match:
        return match.group(1)
    # Also accept partial
    match = re.search(r"\b(CTT\d)\b", text.upper())
    if match:
        return None  # incomplete
    return None


def extract_day(text: str) -> Optional[str]:
    days = {
        "thứ 2": "Thứ 2", "thứ hai": "Thứ 2", "monday": "Thứ 2",
        "thứ 3": "Thứ 3", "thứ ba": "Thứ 3", "tuesday": "Thứ 3",
        "thứ 4": "Thứ 4", "thứ tư": "Thứ 4", "wednesday": "Thứ 4",
        "thứ 5": "Thứ 5", "thứ năm": "Thứ 5", "thursday": "Thứ 5",
        "thứ 6": "Thứ 6", "thứ sáu": "Thứ 6", "friday": "Thứ 6",
        "thứ 7": "Thứ 7", "thứ bảy": "Thứ 7", "saturday": "Thứ 7",
        "chủ nhật": "Chủ nhật", "sunday": "Chủ nhật",
    }
    text_lower = text.lower()
    for key, val in days.items():
        if key in text_lower:
            return val
    return None


def classify_intent(text: str) -> ParsedRequest:
    text_lower = text.lower().strip()
    if not text_lower:
        return ParsedRequest(
            raw=text, intent="empty", confidence=1.0,
            needs_clarification=True,
            clarification_question="Bạn muốn hỏi gì về lịch học, quy định hay thông báo?"
        )

    scores = {}
    for intent, patterns in INTENT_PATTERNS.items():
        score = 0
        for p in patterns:
            if re.search(p, text_lower):
                score += 1
        if score > 0:
            scores[intent] = score

    if not scores:
        return ParsedRequest(
            raw=text, intent="unknown", confidence=0.3,
            needs_clarification=True,
            clarification_question="Mình chưa hiểu rõ. Bạn có thể hỏi về: lịch học, phòng học, quy định, thông báo, deadline hoặc lập kế hoạch tuần."
        )

    best_intent = max(scores, key=scores.get)
    confidence = min(1.0, scores[best_intent] / 2.0)

    entities = {}
    class_id = extract_class_id(text)
    if class_id:
        entities["class_id"] = class_id
    day = extract_day(text)
    if day:
        entities["day"] = day

    # Clarification logic
    needs_clarification = False
    clarification_question = None

    if best_intent == "schedule_query" and "class_id" not in entities:
        needs_clarification = True
        clarification_question = "Bạn muốn xem lịch của lớp nào? (ví dụ: 21CTT1, 22CTT3, 23CTT2)"
    elif best_intent == "out_of_scope":
        confidence = 0.9

    return ParsedRequest(
        raw=text,
        intent=best_intent,
        entities=entities,
        confidence=confidence,
        needs_clarification=needs_clarification,
        clarification_question=clarification_question,
    )
