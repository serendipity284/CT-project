"""Load and manage structured data sources (R3 - Data/Retrieval capability)."""
import json
from pathlib import Path
from typing import Any, Optional

DATA_DIR = Path(__file__).parent.parent / "data"


def load_json(filename: str) -> dict[str, Any]:
    path = DATA_DIR / filename
    with open(path, encoding="utf-8") as f:
        return json.load(f)


class DataStore:
    def __init__(self):
        self.schedules = load_json("schedules.json")
        self.regulations = load_json("regulations.json")["regulations"]
        self.deadlines = load_json("deadlines.json")["deadlines"]
        self.announcements = self._load_announcements()
        self.personal_schedule: Optional[dict] = None
        self.user: Optional[dict] = None  # profile từ login

    def _load_announcements(self) -> list[dict]:
        live_path = DATA_DIR / "announcements_live.json"
        if live_path.exists():
            try:
                data = json.loads(live_path.read_text(encoding="utf-8"))
                items = data.get("announcements", [])
                if items:
                    return items
            except Exception:
                pass
        return load_json("announcements.json")["announcements"]

    def reload_announcements(self):
        self.announcements = self._load_announcements()

    def set_user(self, user: dict | None):
        self.user = user

    def get_user(self) -> dict | None:
        return self.user

    def set_personal_schedule(self, schedule_data: dict | None):
        self.personal_schedule = schedule_data

    def get_personal_schedule(self) -> dict | None:
        return self.personal_schedule

    def get_class_schedule(self, class_id: str) -> dict | None:
        if class_id and class_id.upper() in ("PERSONAL", "MINE", "ME", "TÔI", "TOI"):
            return self.personal_schedule
        return self.schedules["classes"].get(class_id.upper()) if class_id else None

    def get_all_class_ids(self) -> list[str]:
        ids = list(self.schedules["classes"].keys())
        if self.personal_schedule:
            ids.insert(0, "PERSONAL")
        return ids

    def search_regulations(self, query: str) -> list[dict]:
        query_lower = query.lower()
        results = []
        for reg in self.regulations:
            score = sum(1 for kw in reg["keywords"] if kw in query_lower)
            if score > 0 or any(kw in query_lower for kw in reg["title"].lower().split()):
                results.append((score, reg))
        results.sort(key=lambda x: x[0], reverse=True)
        return [r[1] for r in results[:3]]

    def get_recent_announcements(self, limit: int = 5) -> list[dict]:
        # Nếu user thuộc FIT hoặc chưa login → dùng nguồn FIT/live
        sorted_anns = sorted(self.announcements, key=lambda x: x.get("date", ""), reverse=True)
        return sorted_anns[:limit]

    def search_announcements(self, query: str) -> list[dict]:
        query_lower = query.lower()
        results = []
        for ann in self.announcements:
            score = sum(1 for kw in ann.get("keywords", []) if kw in query_lower)
            title = ann.get("title", "").lower()
            content = ann.get("content", "").lower()
            if score > 0 or query_lower in title or query_lower in content:
                results.append((score, ann))
        results.sort(key=lambda x: x[0], reverse=True)
        return [r[1] for r in results[:5]]

    def get_upcoming_deadlines(self, limit: int = 5) -> list[dict]:
        from datetime import datetime
        today = datetime.now().strftime("%Y-%m-%d")
        upcoming = [d for d in self.deadlines if d["date"] >= today]
        upcoming.sort(key=lambda x: x["date"])
        return upcoming[:limit]

    def get_room_info(self, room_id: str) -> dict | None:
        return self.schedules["rooms"].get(room_id.upper())
