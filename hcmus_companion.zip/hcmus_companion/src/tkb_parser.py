"""
Parser TKB cá nhân từ file CSV / Excel / JSON.
Hỗ trợ cá nhân hóa lịch học (R1 + R2).
"""
import json
import re
from io import BytesIO
from typing import Any

import pandas as pd


# Chuẩn hóa tên cột phổ biến
COLUMN_ALIASES = {
    "day": ["day", "thứ", "thu", "weekday", "ngày"],
    "period": ["period", "tiết", "tiet", "tiết học"],
    "time": ["time", "giờ", "gio", "thời gian", "thoigian"],
    "course": ["course", "môn", "mon", "môn học", "ten mon", "tên môn", "subject"],
    "room": ["room", "phòng", "phong", "phòng học"],
    "lecturer": ["lecturer", "gv", "giảng viên", "giang vien", "teacher"],
}

DAY_MAP = {
    "2": "Thứ 2", "thứ 2": "Thứ 2", "thu 2": "Thứ 2", "monday": "Thứ 2", "t2": "Thứ 2",
    "3": "Thứ 3", "thứ 3": "Thứ 3", "thu 3": "Thứ 3", "tuesday": "Thứ 3", "t3": "Thứ 3",
    "4": "Thứ 4", "thứ 4": "Thứ 4", "thu 4": "Thứ 4", "wednesday": "Thứ 4", "t4": "Thứ 4",
    "5": "Thứ 5", "thứ 5": "Thứ 5", "thu 5": "Thứ 5", "thursday": "Thứ 5", "t5": "Thứ 5",
    "6": "Thứ 6", "thứ 6": "Thứ 6", "thu 6": "Thứ 6", "friday": "Thứ 6", "t6": "Thứ 6",
    "7": "Thứ 7", "thứ 7": "Thứ 7", "thu 7": "Thứ 7", "saturday": "Thứ 7", "t7": "Thứ 7",
    "cn": "Chủ nhật", "chủ nhật": "Chủ nhật", "sunday": "Chủ nhật",
}


def _normalize_col(name: str) -> str | None:
    n = str(name).strip().lower()
    for canonical, aliases in COLUMN_ALIASES.items():
        if n in aliases or any(a in n for a in aliases):
            return canonical
    return None


def _normalize_day(val: Any) -> str:
    s = str(val).strip().lower()
    for k, v in DAY_MAP.items():
        if k == s or k in s:
            return v
    # fallback: giữ nguyên nếu đã đúng format
    if s.startswith("thứ") or s == "chủ nhật":
        return str(val).strip().title()
    return str(val).strip()


def parse_dataframe(df: pd.DataFrame) -> list[dict]:
    """Chuyển DataFrame thành list schedule items chuẩn."""
    # Map cột
    col_map = {}
    for c in df.columns:
        canon = _normalize_col(c)
        if canon:
            col_map[canon] = c

    if "course" not in col_map and "day" not in col_map:
        raise ValueError(
            "Không nhận diện được cột. Cần có ít nhất cột 'Môn' (course) và 'Thứ' (day). "
            f"Các cột hiện có: {list(df.columns)}"
        )

    items = []
    for _, row in df.iterrows():
        item = {
            "day": _normalize_day(row[col_map["day"]]) if "day" in col_map else "Thứ 2",
            "period": str(row[col_map["period"]]).strip() if "period" in col_map else "?",
            "time": str(row[col_map["time"]]).strip() if "time" in col_map else "",
            "course": str(row[col_map["course"]]).strip() if "course" in col_map else "?",
            "room": str(row[col_map["room"]]).strip() if "room" in col_map else "?",
            "lecturer": str(row[col_map["lecturer"]]).strip() if "lecturer" in col_map else "",
        }
        # Bỏ dòng trống
        if item["course"] in ("?", "nan", "") or item["day"] in ("nan", ""):
            continue
        items.append(item)
    return items


def parse_uploaded_file(file_bytes: bytes, filename: str) -> dict:
    """
    Parse file upload → dict dạng:
    {
      "name": "TKB cá nhân",
      "schedule": [ {...}, ... ],
      "source": filename
    }
    """
    name_lower = filename.lower()

    if name_lower.endswith(".json"):
        data = json.loads(file_bytes.decode("utf-8"))
        if isinstance(data, list):
            schedule = data
        elif isinstance(data, dict) and "schedule" in data:
            schedule = data["schedule"]
        else:
            raise ValueError("JSON phải là list các buổi học hoặc object có key 'schedule'")
        return {"name": "TKB cá nhân (JSON)", "schedule": schedule, "source": filename}

    if name_lower.endswith((".xlsx", ".xls")):
        df = pd.read_excel(BytesIO(file_bytes))
    elif name_lower.endswith(".csv"):
        # Thử nhiều encoding
        for enc in ("utf-8", "utf-8-sig", "cp1258", "latin-1"):
            try:
                df = pd.read_csv(BytesIO(file_bytes), encoding=enc)
                break
            except Exception:
                continue
        else:
            raise ValueError("Không đọc được file CSV (thử encoding utf-8)")
    else:
        raise ValueError("Chỉ hỗ trợ .csv, .xlsx, .xls, .json")

    schedule = parse_dataframe(df)
    if not schedule:
        raise ValueError("Không parse được buổi học nào từ file. Kiểm tra lại tên cột.")

    return {
        "name": f"TKB cá nhân ({filename})",
        "schedule": schedule,
        "source": filename,
    }


def make_sample_csv() -> str:
    """Tạo nội dung CSV mẫu để user tải về tham khảo."""
    return (
        "Thứ,Tiết,Giờ,Môn học,Phòng,Giảng viên\n"
        "Thứ 2,1-3,07:30-09:50,Cấu trúc dữ liệu,E202,TS. Nguyễn Văn A\n"
        "Thứ 2,4-6,10:00-12:20,Cơ sở dữ liệu,E305,ThS. Trần Thị B\n"
        "Thứ 4,1-3,07:30-09:50,Lập trình hướng đối tượng,F102,TS. Lê Văn C\n"
        "Thứ 5,7-9,13:00-15:20,Mạng máy tính,E201,PGS. Phạm D\n"
        "Thứ 6,1-3,07:30-09:50,Toán rời rạc,C301,TS. Hoàng E\n"
    )
