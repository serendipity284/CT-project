"""
HCMUS Companion – FastAPI + Auth (SQLite)
Chạy: uvicorn main:app --reload --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, UploadFile, HTTPException, Request, Response, Depends, Cookie
from fastapi.responses import HTMLResponse, Response as FastResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

from src.router import Router
from src.tkb_parser import parse_uploaded_file, make_sample_csv
from src.crawler import refresh_announcements, load_live_announcements
from src import auth

app = FastAPI(
    title="HCMUS Companion",
    description="Smart Virtual Assistant – cá nhân hóa theo sinh viên",
    version="1.2.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Router dùng chung logic; personal TKB lưu theo user_id
router = Router()
# user_id -> personal schedule dict
_tkb_store: dict[int, dict] = {}

STATIC_DIR = ROOT / "static"
TEMPLATES_DIR = ROOT / "templates"
SESSION_COOKIE = "hcmus_session"


# ── Schemas ──────────────────────────────────────────
class ChatRequest(BaseModel):
    message: str


class RegisterRequest(BaseModel):
    mssv: str
    password: str
    display_name: str
    faculty: str
    major: str


class LoginRequest(BaseModel):
    mssv: str
    password: str


# ── Auth helpers ─────────────────────────────────────
def _get_token(request: Request, hcmus_session: Optional[str] = Cookie(None)) -> Optional[str]:
    return hcmus_session or request.headers.get("X-Session-Token")


def current_user(
    request: Request, hcmus_session: Optional[str] = Cookie(None)
) -> Optional[dict]:
    token = _get_token(request, hcmus_session)
    return auth.get_user_by_token(token)


def require_user(
    request: Request, hcmus_session: Optional[str] = Cookie(None)
) -> dict:
    user = current_user(request, hcmus_session)
    if not user:
        raise HTTPException(401, "Chưa đăng nhập")
    return user


def _bind_user_context(user: Optional[dict]):
    """Gắn profile + TKB cá nhân vào DataStore trước khi xử lý."""
    router.store.set_user(user)
    if user and user["id"] in _tkb_store:
        router.store.set_personal_schedule(_tkb_store[user["id"]])
    else:
        # Guest: không xóa TKB nếu đang demo không login — giữ None khi có user khác
        if user:
            router.store.set_personal_schedule(None)
        # nếu guest, giữ nguyên (có thể None)


# ── Pages ────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
def index():
    return HTMLResponse((TEMPLATES_DIR / "index.html").read_text(encoding="utf-8"))


# ── Auth API ─────────────────────────────────────────
@app.get("/api/faculties")
def faculties():
    return auth.list_faculties()


@app.post("/api/register")
def register(body: RegisterRequest, response: Response):
    try:
        user = auth.register_user(
            mssv=body.mssv,
            password=body.password,
            display_name=body.display_name,
            faculty=body.faculty,
            major=body.major,
        )
    except ValueError as e:
        raise HTTPException(400, str(e))
    token = auth.create_session(user["id"])
    response.set_cookie(
        SESSION_COOKIE, token, httponly=True, samesite="lax", max_age=60 * 60 * 24 * 14
    )
    return {"ok": True, "user": user, "token": token}


@app.post("/api/login")
def login(body: LoginRequest, response: Response):
    try:
        user = auth.authenticate(body.mssv, body.password)
    except ValueError as e:
        raise HTTPException(401, str(e))
    token = auth.create_session(user["id"])
    response.set_cookie(
        SESSION_COOKIE, token, httponly=True, samesite="lax", max_age=60 * 60 * 24 * 14
    )
    _bind_user_context(user)
    return {"ok": True, "user": user, "token": token}


@app.post("/api/logout")
def logout(
    response: Response,
    request: Request,
    hcmus_session: Optional[str] = Cookie(None),
):
    token = _get_token(request, hcmus_session)
    if token:
        auth.delete_session(token)
    response.delete_cookie(SESSION_COOKIE)
    router.store.set_user(None)
    router.store.set_personal_schedule(None)
    return {"ok": True}


@app.get("/api/me")
def me(user: Optional[dict] = Depends(current_user)):
    if not user:
        return {"authenticated": False, "user": None}
    has_tkb = user["id"] in _tkb_store
    return {
        "authenticated": True,
        "user": user,
        "has_personal_tkb": has_tkb,
        "tkb_count": len(_tkb_store[user["id"]]["schedule"]) if has_tkb else 0,
    }


# ── Core API ─────────────────────────────────────────
@app.get("/api/health")
def health(user: Optional[dict] = Depends(current_user)):
    live = load_live_announcements()
    return {
        "status": "ok",
        "authenticated": user is not None,
        "user": user,
        "live_announcements": live.get("count", 0) if live else 0,
        "live_crawled_at": live.get("crawled_at") if live else None,
    }


@app.post("/api/chat")
def chat(req: ChatRequest, user: Optional[dict] = Depends(current_user)):
    if not req.message or not req.message.strip():
        raise HTTPException(400, "Message is empty")
    _bind_user_context(user)
    result = router.handle(req.message.strip())

    # Chào kèm khoa nếu đã login và intent unknown lần đầu — optional soft touch
    prefix = ""
    if user and result["type"] in ("unknown", "clarification"):
        pass  # giữ nguyên

    return {
        "response": prefix + result["response"],
        "intent": result["intent"],
        "type": result["type"],
        "confidence": result["confidence"],
        "entities": result.get("entities", {}),
        "has_personal_tkb": router.store.get_personal_schedule() is not None,
        "user": user,
    }


@app.post("/api/upload-tkb")
async def upload_tkb(
    file: UploadFile = File(...),
    user: dict = Depends(require_user),
):
    if not file.filename:
        raise HTTPException(400, "No filename")
    allowed = (".csv", ".xlsx", ".xls", ".json")
    if not file.filename.lower().endswith(allowed):
        raise HTTPException(400, f"Chỉ hỗ trợ: {', '.join(allowed)}")
    raw = await file.read()
    try:
        data = parse_uploaded_file(raw, file.filename)
        _tkb_store[user["id"]] = data
        router.store.set_personal_schedule(data)
        router.store.set_user(user)
        return {
            "ok": True,
            "message": f"Đã nạp {len(data['schedule'])} buổi học từ {file.filename}",
            "count": len(data["schedule"]),
            "name": data.get("name"),
        }
    except Exception as e:
        raise HTTPException(400, f"Lỗi parse file: {e}")


@app.delete("/api/tkb")
def clear_tkb(user: dict = Depends(require_user)):
    _tkb_store.pop(user["id"], None)
    router.store.set_personal_schedule(None)
    return {"ok": True, "message": "Đã xóa TKB cá nhân"}


@app.get("/api/tkb")
def get_tkb(user: Optional[dict] = Depends(current_user)):
    if not user or user["id"] not in _tkb_store:
        return {"has_tkb": False}
    p = _tkb_store[user["id"]]
    return {
        "has_tkb": True,
        "name": p.get("name"),
        "count": len(p.get("schedule", [])),
        "source": p.get("source"),
    }


@app.post("/api/refresh-news")
def refresh_news():
    ok, msg, items = refresh_announcements()
    if ok:
        router.store.reload_announcements()
    return {
        "ok": ok,
        "message": msg,
        "count": len(items),
        "items": [
            {"title": i["title"], "url": i.get("url"), "priority": i.get("priority")}
            for i in items[:8]
        ],
    }


@app.get("/api/sample-csv")
def sample_csv():
    content = make_sample_csv()
    return FastResponse(
        content=content,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=tkb_mau.csv"},
    )


if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
