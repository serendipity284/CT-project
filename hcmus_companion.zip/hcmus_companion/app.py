"""
HCMUS Companion – Smart Virtual Assistant (MVP+)
CSC10014 – Computational Thinking 2026

Pipeline: REQUEST → UNDERSTAND → ROUTE → RETRIEVE/COMPUTE → VERIFY → RESPOND

Nâng cấp:
- Upload TKB cá nhân (CSV/Excel/JSON) → cá nhân hóa
- Crawl thông báo từ fit.hcmus.edu.vn
"""
import streamlit as st
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from src.router import Router
from src.tkb_parser import parse_uploaded_file, make_sample_csv
from src.crawler import refresh_announcements, load_live_announcements

st.set_page_config(
    page_title="HCMUS Companion",
    page_icon="🎓",
    layout="centered",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
    .main-header { font-size: 1.8rem; font-weight: 700; color: #1a365d; margin-bottom: 0.2rem; }
    .sub-header { color: #4a5568; font-size: 0.95rem; margin-bottom: 1.5rem; }
</style>
""", unsafe_allow_html=True)

# ── Init ──────────────────────────────────────────────
if "router" not in st.session_state:
    st.session_state.router = Router()
if "messages" not in st.session_state:
    st.session_state.messages = [
        {
            "role": "assistant",
            "content": (
                "Xin chào! Mình là **HCMUS Companion** 👋\n\n"
                "Mình có thể giúp bạn:\n"
                "• Xem lịch học / phòng học (theo lớp hoặc **TKB cá nhân**)\n"
                "• Tra cứu quy định học vụ\n"
                "• Xem thông báo mới từ website FIT\n"
                "• Deadline & lập kế hoạch tuần\n"
                "• Kiểm tra xung đột lịch\n\n"
                "👉 **Upload TKB** ở sidebar để cá nhân hóa, "
                "hoặc bấm **Lấy thông báo mới** để crawl từ fit.hcmus.edu.vn."
            ),
        }
    ]

router: Router = st.session_state.router

# ── Sidebar ───────────────────────────────────────────
with st.sidebar:
    st.markdown("### 🎓 HCMUS Companion")
    st.markdown("Trợ lý ảo đời sống học tập **FIT@HCMUS**")
    st.markdown("---")

    # --- Upload TKB ---
    st.markdown("#### 📅 TKB cá nhân")
    uploaded = st.file_uploader(
        "Upload file TKB (CSV / Excel / JSON)",
        type=["csv", "xlsx", "xls", "json"],
        help="Cột gợi ý: Thứ, Tiết, Giờ, Môn học, Phòng, Giảng viên",
    )
    if uploaded is not None:
        try:
            data = parse_uploaded_file(uploaded.getvalue(), uploaded.name)
            router.store.set_personal_schedule(data)
            st.success(f"Đã nạp {len(data['schedule'])} buổi học từ **{uploaded.name}**")
            st.caption("Giờ bạn có thể hỏi: “Lịch học của tôi”, “Lập kế hoạch tuần”…")
        except Exception as e:
            st.error(f"Lỗi parse file: {e}")

    if router.store.get_personal_schedule():
        p = router.store.get_personal_schedule()
        st.info(f"TKB đang dùng: **{p.get('name', 'cá nhân')}** ({len(p['schedule'])} buổi)")
        if st.button("Xóa TKB cá nhân"):
            router.store.set_personal_schedule(None)
            st.rerun()

    st.download_button(
        "⬇️ Tải file CSV mẫu",
        data=make_sample_csv(),
        file_name="tkb_mau.csv",
        mime="text/csv",
    )

    st.markdown("---")

    # --- Crawl announcements ---
    st.markdown("#### 📢 Thông báo từ web FIT")
    live = load_live_announcements()
    if live:
        st.caption(f"Cache: {live.get('crawled_at', '?')} ({live.get('count', 0)} tin)")
    else:
        st.caption("Chưa có dữ liệu live (đang dùng mock local)")

    if st.button("🔄 Lấy thông báo mới từ FIT", use_container_width=True):
        with st.spinner("Đang crawl fit.hcmus.edu.vn..."):
            ok, msg, items = refresh_announcements()
            if ok:
                router.store.reload_announcements()
                st.success(msg)
            else:
                st.warning(msg)

    st.markdown("---")
    st.markdown("**Ví dụ câu hỏi:**")
    examples = [
        "Lịch học của tôi",
        "Lịch học lớp 21CTT1",
        "Thông báo mới nhất",
        "Quy định về học cải thiện điểm",
        "Deadline sắp tới",
        "Lập kế hoạch tuần",
        "Kiểm tra xung đột lớp 21CTT1 thứ 4 tiết 4-6",
    ]
    for ex in examples:
        if st.button(ex, key=f"ex_{ex}", use_container_width=True):
            st.session_state["pending_input"] = ex

    st.markdown("---")
    st.caption("R1–R8 • Upload TKB + Crawl FIT • Deterministic + Retrieval + Routing")

# ── Main chat ─────────────────────────────────────────
st.markdown('<p class="main-header">🎓 HCMUS Companion</p>', unsafe_allow_html=True)
st.markdown(
    '<p class="sub-header">Smart Virtual Assistant cho sinh viên FIT@HCMUS '
    '(có TKB cá nhân + thông báo live)</p>',
    unsafe_allow_html=True,
)

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

prompt = None
if "pending_input" in st.session_state:
    prompt = st.session_state.pop("pending_input")

user_input = st.chat_input("Nhập câu hỏi của bạn...")
if user_input:
    prompt = user_input

if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Đang xử lý..."):
            result = router.handle(prompt)
            response = result["response"]
            st.markdown(response)
            with st.expander("🔍 Chi tiết pipeline (debug)", expanded=False):
                st.json({
                    "intent": result["intent"],
                    "entities": result.get("entities", {}),
                    "type": result["type"],
                    "confidence": result["confidence"],
                    "has_personal_tkb": router.store.get_personal_schedule() is not None,
                })

    st.session_state.messages.append({"role": "assistant", "content": response})
