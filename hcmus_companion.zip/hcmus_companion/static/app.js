/* HCMUS Companion – Frontend with Auth */

const chatArea = document.getElementById("chatArea");
const chatForm = document.getElementById("chatForm");
const chatInput = document.getElementById("chatInput");
const btnSend = document.getElementById("btnSend");
const tkbFile = document.getElementById("tkbFile");
const btnUpload = document.getElementById("btnUpload");
const tkbStatus = document.getElementById("tkbStatus");
const btnClearTkb = document.getElementById("btnClearTkb");
const btnRefreshNews = document.getElementById("btnRefreshNews");
const newsMeta = document.getElementById("newsMeta");
const newsPreview = document.getElementById("newsPreview");
const healthBadge = document.getElementById("healthBadge");
const btnClearChat = document.getElementById("btnClearChat");
const guestBox = document.getElementById("guestBox");
const userBox = document.getElementById("userBox");
const userName = document.getElementById("userName");
const userMeta = document.getElementById("userMeta");
const facultySelect = document.getElementById("facultySelect");
const majorSelect = document.getElementById("majorSelect");

let facultiesData = {};
let currentUser = null;

function appendMsg(role, text, meta) {
  const div = document.createElement("div");
  div.className = `msg ${role}`;
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.innerHTML = formatText(text);
  div.appendChild(bubble);
  if (meta) {
    const m = document.createElement("div");
    m.className = "meta";
    m.textContent = meta;
    div.appendChild(m);
  }
  chatArea.appendChild(div);
  chatArea.scrollTop = chatArea.scrollHeight;
}

function formatText(text) {
  return text
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/\n/g, "<br>");
}

function showTyping() {
  const div = document.createElement("div");
  div.className = "msg bot";
  div.id = "typing";
  div.innerHTML = '<div class="bubble typing"><span></span><span></span><span></span></div>';
  chatArea.appendChild(div);
  chatArea.scrollTop = chatArea.scrollHeight;
}
function hideTyping() {
  const t = document.getElementById("typing");
  if (t) t.remove();
}

async function sendMessage(text) {
  if (!text.trim()) return;
  appendMsg("user", text);
  chatInput.value = "";
  btnSend.disabled = true;
  showTyping();
  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ message: text }),
    });
    const data = await res.json();
    hideTyping();
    if (!res.ok) appendMsg("bot", data.detail || "Lỗi server");
    else appendMsg("bot", data.response, `${data.intent} · conf ${data.confidence.toFixed(2)}`);
  } catch (e) {
    hideTyping();
    appendMsg("bot", "Không kết nối được server.");
  }
  btnSend.disabled = false;
  chatInput.focus();
}

chatForm.addEventListener("submit", (e) => {
  e.preventDefault();
  sendMessage(chatInput.value);
});
document.getElementById("exampleChips").addEventListener("click", (e) => {
  if (e.target.dataset.q) sendMessage(e.target.dataset.q);
});
btnClearChat.addEventListener("click", () => {
  chatArea.innerHTML = "";
  appendMsg("bot", "Đã xóa hội thoại.");
});

// ── Auth tabs ──
document.querySelectorAll(".auth-tabs .tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".auth-tabs .tab").forEach((t) => t.classList.remove("active"));
    tab.classList.add("active");
    const isLogin = tab.dataset.tab === "login";
    document.getElementById("loginForm").classList.toggle("hidden", !isLogin);
    document.getElementById("registerForm").classList.toggle("hidden", isLogin);
  });
});

async function loadFaculties() {
  const res = await fetch("/api/faculties");
  facultiesData = await res.json();
  facultySelect.innerHTML = '<option value="">-- Chọn khoa * --</option>';
  Object.entries(facultiesData).forEach(([k, v]) => {
    const opt = document.createElement("option");
    opt.value = k;
    opt.textContent = v.name;
    facultySelect.appendChild(opt);
  });
}

facultySelect.addEventListener("change", () => {
  const fac = facultySelect.value;
  majorSelect.innerHTML = '<option value="">-- Chọn ngành * --</option>';
  if (!fac || !facultiesData[fac]) return;
  Object.entries(facultiesData[fac].majors).forEach(([k, name]) => {
    const opt = document.createElement("option");
    opt.value = k;
    opt.textContent = name;
    majorSelect.appendChild(opt);
  });
});

function showUser(user) {
  currentUser = user;
  guestBox.classList.add("hidden");
  userBox.classList.remove("hidden");
  userName.textContent = user.display_name;
  userMeta.textContent = `${user.mssv} · ${user.faculty_name} · ${user.major_name}`;
}

function showGuest() {
  currentUser = null;
  guestBox.classList.remove("hidden");
  userBox.classList.add("hidden");
}

document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const err = document.getElementById("loginError");
  err.textContent = "";
  try {
    const res = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ mssv: fd.get("mssv"), password: fd.get("password") }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Đăng nhập thất bại");
    showUser(data.user);
    appendMsg("bot", `Chào ${data.user.display_name}! Khoa: **${data.user.faculty_name}** · Ngành: **${data.user.major_name}**.`);
    refreshMe();
  } catch (ex) {
    err.textContent = ex.message;
  }
});

document.getElementById("registerForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const err = document.getElementById("registerError");
  err.textContent = "";
  try {
    const res = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({
        mssv: fd.get("mssv"),
        password: fd.get("password"),
        display_name: fd.get("display_name"),
        faculty: fd.get("faculty"),
        major: fd.get("major"),
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Đăng ký thất bại");
    showUser(data.user);
    appendMsg("bot", `Đăng ký thành công! Xin chào **${data.user.display_name}** (${data.user.faculty_name}). Hãy upload TKB để cá nhân hóa lịch học.`);
    refreshMe();
  } catch (ex) {
    err.textContent = ex.message;
  }
});

document.getElementById("btnLogout").addEventListener("click", async () => {
  await fetch("/api/logout", { method: "POST", credentials: "include" });
  showGuest();
  tkbStatus.classList.add("hidden");
  btnClearTkb.classList.add("hidden");
  appendMsg("bot", "Đã đăng xuất.");
});

// ── TKB ──
btnUpload.addEventListener("click", () => tkbFile.click());
tkbFile.addEventListener("change", async () => {
  const file = tkbFile.files[0];
  if (!file) return;
  if (!currentUser) {
    appendMsg("bot", "Bạn cần **đăng nhập** trước khi upload TKB.");
    tkbFile.value = "";
    return;
  }
  const fd = new FormData();
  fd.append("file", file);
  btnUpload.disabled = true;
  try {
    const res = await fetch("/api/upload-tkb", { method: "POST", body: fd, credentials: "include" });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Upload failed");
    tkbStatus.textContent = `✅ ${data.message}`;
    tkbStatus.classList.remove("hidden");
    btnClearTkb.classList.remove("hidden");
    appendMsg("bot", data.message + " Bạn có thể hỏi “Lịch học của tôi”.");
  } catch (e) {
    tkbStatus.textContent = `❌ ${e.message}`;
    tkbStatus.classList.remove("hidden");
  }
  btnUpload.disabled = false;
  tkbFile.value = "";
});

btnClearTkb.addEventListener("click", async () => {
  await fetch("/api/tkb", { method: "DELETE", credentials: "include" });
  tkbStatus.classList.add("hidden");
  btnClearTkb.classList.add("hidden");
  appendMsg("bot", "Đã xóa TKB cá nhân.");
});

btnRefreshNews.addEventListener("click", async () => {
  btnRefreshNews.disabled = true;
  btnRefreshNews.textContent = "Đang crawl…";
  try {
    const res = await fetch("/api/refresh-news", { method: "POST" });
    const data = await res.json();
    newsMeta.textContent = data.message;
    newsPreview.innerHTML = "";
    (data.items || []).forEach((item) => {
      const a = document.createElement("a");
      a.href = item.url || "#";
      a.target = "_blank";
      a.textContent = (item.priority === "high" ? "🔴 " : "🟡 ") + item.title;
      newsPreview.appendChild(a);
    });
  } catch (e) {
    newsMeta.textContent = "Lỗi: " + e.message;
  }
  btnRefreshNews.disabled = false;
  btnRefreshNews.textContent = "🔄 Lấy tin mới";
});

async function refreshMe() {
  const res = await fetch("/api/me", { credentials: "include" });
  const data = await res.json();
  if (data.authenticated) {
    showUser(data.user);
    if (data.has_personal_tkb) {
      tkbStatus.textContent = `✅ TKB đã lưu (${data.tkb_count} buổi)`;
      tkbStatus.classList.remove("hidden");
      btnClearTkb.classList.remove("hidden");
    }
  } else {
    showGuest();
  }
}

async function checkHealth() {
  try {
    const res = await fetch("/api/health", { credentials: "include" });
    const data = await res.json();
    healthBadge.textContent = "● online";
    healthBadge.style.color = "#16a34a";
    if (data.live_announcements) {
      newsMeta.textContent = `Cache: ${data.live_crawled_at || "?"} (${data.live_announcements} tin)`;
    }
  } catch {
    healthBadge.textContent = "● offline";
    healthBadge.style.color = "#dc2626";
  }
}

(async function init() {
  await loadFaculties();
  await refreshMe();
  await checkHealth();
})();
